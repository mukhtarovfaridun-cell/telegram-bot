#!/bin/bash
python bot_full_final_safe.py
